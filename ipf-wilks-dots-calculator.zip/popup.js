const storage = typeof browser !== "undefined" ? browser.storage.local : chrome.storage.local;
const genderEl = document.getElementById("gender");
const unitEl = document.getElementById("unit");
const bodyweightEl = document.getElementById("bodyweight");
const totalEl = document.getElementById("total");
const ipfEl = document.getElementById("ipf");
const wilksEl = document.getElementById("wilks");
const historyEl = document.getElementById("history");

function toKg(v, unit) {
  return unit === "kg" ? v : v * 0.45359237;
}

function round2(v) {
  return Math.round((v + Number.EPSILON) * 100) / 100;
}

function calcWilks(gender, bwKg, totalKg) {
  if (!Number.isFinite(bwKg) || !Number.isFinite(totalKg) || bwKg <= 0 || totalKg <= 0) return 0;
  const c =
    gender === "male"
      ? { a: -216.0475144, b: 16.2606339, c: -0.002388645, d: -0.00113732, e: 0.00000701863, f: -0.00000001291, m: 500 }
      : { a: 594.31747775582, b: -27.23842536447, c: 0.82112226871, d: -0.00930733913, e: 0.00004731582, f: -0.00000009054, m: 500 };
  const w = bwKg;
  const den = c.a + c.b * w + c.c * w ** 2 + c.d * w ** 3 + c.e * w ** 4 + c.f * w ** 5;
  if (den <= 0) return 0;
  return round2(totalKg * (c.m / den));
}

function calcIpf(gender, bwKg, totalKg) {
  if (!Number.isFinite(bwKg) || !Number.isFinite(totalKg) || bwKg <= 0 || totalKg <= 0) return 0;
  const c = gender === "male" ? { A: 1199.72839, B: 1025.18162, C: 0.00921 } : { A: 610.32796, B: 1045.59282, C: 0.03048 };
  const den = c.A - c.B * Math.exp(-c.C * bwKg);
  if (den <= 0) return 0;
  return round2((totalKg * 100) / den);
}

async function getSaved() {
  const data = await storage.get(["entries"]);
  return Array.isArray(data.entries) ? data.entries : [];
}

async function setSaved(entries) {
  await storage.set({ entries });
}

function renderHistory(entries) {
  historyEl.innerHTML = "";
  entries.forEach((e) => {
    const li = document.createElement("li");
    li.textContent = `${e.gender} | ${e.bodyweight}${e.unit} | ${e.total}${e.unit} | IPF ${e.ipf} | Wilks ${e.wilks}`;
    historyEl.appendChild(li);
  });
}

function compute() {
  const gender = genderEl.value;
  const unit = unitEl.value;
  const bw = Number(bodyweightEl.value);
  const total = Number(totalEl.value);
  const bwKg = toKg(bw, unit);
  const totalKg = toKg(total, unit);
  const ipf = calcIpf(gender, bwKg, totalKg);
  const wilks = calcWilks(gender, bwKg, totalKg);
  ipfEl.textContent = ipf.toFixed(2);
  wilksEl.textContent = wilks.toFixed(2);
  return { gender, unit, bodyweight: round2(bw), total: round2(total), ipf: ipf.toFixed(2), wilks: wilks.toFixed(2) };
}

["input", "change"].forEach((evt) => {
  bodyweightEl.addEventListener(evt, compute);
  totalEl.addEventListener(evt, compute);
  genderEl.addEventListener(evt, compute);
  unitEl.addEventListener(evt, compute);
});

document.getElementById("save").addEventListener("click", async () => {
  const next = compute();
  const entries = await getSaved();
  entries.unshift(next);
  await setSaved(entries.slice(0, 25));
  renderHistory(await getSaved());
});

document.getElementById("clear").addEventListener("click", async () => {
  await setSaved([]);
  renderHistory([]);
});

document.getElementById("copy").addEventListener("click", async () => {
  const next = compute();
  const text = `IPF ${next.ipf} | Wilks ${next.wilks} (${next.gender}, ${next.bodyweight}${next.unit}, ${next.total}${next.unit})`;
  await navigator.clipboard.writeText(text);
});

(async function init() {
  compute();
  renderHistory(await getSaved());
})();
